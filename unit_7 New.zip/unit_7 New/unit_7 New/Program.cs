﻿using System;
using System.Diagnostics;

class OptimizedMergeSort
{
    public static void Merge(int[] arr, int left, int middle, int right)
    {
        int n1 = middle - left + 1;
        int n2 = right - middle;

        int[] leftArr = new int[n1];
        int[] rightArr = new int[n2];

        for (int i = 0; i < n1; i++)
            leftArr[i] = arr[left + i];
        for (int j = 0; j < n2; j++)
            rightArr[j] = arr[middle + 1 + j];

        int k = left;
        int i1 = 0, i2 = 0;

        while (i1 < n1 && i2 < n2)
        {
            if (leftArr[i1] <= rightArr[i2])
            {
                arr[k] = leftArr[i1];
                i1++;
            }
            else
            {
                arr[k] = rightArr[i2];
                i2++;
            }
            k++;
        }

        while (i1 < n1)
        {
            arr[k] = leftArr[i1];
            i1++;
            k++;
        }

        while (i2 < n2)
        {
            arr[k] = rightArr[i2];
            i2++;
            k++;
        }
    }

    public static void OptimizedSort(int[] arr, int left, int right)
    {
        if (left < right)
        {
            // Use Insertion Sort for small subarrays to improve performance
            if (right - left <= 15)
            {
                InsertionSort(arr, left, right);
                return;
            }

            int middle = (left + right) / 2;
            OptimizedSort(arr, left, middle);
            OptimizedSort(arr, middle + 1, right);

            // Skip merge if the arrays are already in order
            if (arr[middle] <= arr[middle + 1])
                return;

            Merge(arr, left, middle, right);
        }
    }

    public static void InsertionSort(int[] arr, int left, int right)
    {
        for (int i = left + 1; i <= right; i++)
        {
            int key = arr[i];
            int j = i - 1;
            while (j >= left && arr[j] > key)
            {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
        }
    }

    static void Main(string[] args)
    {
        // Create small, medium, and large datasets
        int[] smallData = new int[10];
        int[] mediumData = new int[1000];
        int[] largeData = new int[10000];
        Random rand = new Random();

        for (int i = 0; i < smallData.Length; i++)
            smallData[i] = rand.Next(1, 100);

        for (int i = 0; i < mediumData.Length; i++)
            mediumData[i] = rand.Next(1, 1000);

        for (int i = 0; i < largeData.Length; i++)
            largeData[i] = rand.Next(1, 10000);

        // Measure execution time for the optimized algorithm
        Stopwatch stopwatch = new Stopwatch();

        // Optimized Merge Sort for Small Dataset
        int[] smallDataOptimized = new int[smallData.Length];
        Array.Copy(smallData, smallDataOptimized, smallData.Length);
        stopwatch.Start();
        OptimizedSort(smallDataOptimized, 0, smallDataOptimized.Length - 1);
        stopwatch.Stop();
        Console.WriteLine("Optimized Execution Time for Small Dataset: " + stopwatch.ElapsedMilliseconds + " milliseconds");

        // Optimized Merge Sort for Medium Dataset
        int[] mediumDataOptimized = new int[mediumData.Length];
        Array.Copy(mediumData, mediumDataOptimized, mediumData.Length);
        stopwatch.Reset();
        stopwatch.Start();
        OptimizedSort(mediumDataOptimized, 0, mediumDataOptimized.Length - 1);
        stopwatch.Stop();
        Console.WriteLine("Optimized Execution Time for Medium Dataset: " + stopwatch.ElapsedMilliseconds + " milliseconds");

        // Optimized Merge Sort for Large Dataset
        int[] largeDataOptimized = new int[largeData.Length];
        Array.Copy(largeData, largeDataOptimized, largeData.Length);
        stopwatch.Reset();
        stopwatch.Start();
        OptimizedSort(largeDataOptimized, 0, largeDataOptimized.Length - 1);
        stopwatch.Stop();
        Console.WriteLine("Optimized Execution Time for Large Dataset: " + stopwatch.ElapsedMilliseconds + " milliseconds");
    }
}
